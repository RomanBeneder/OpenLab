#ifndef _CMSIS_H_
#define _CMSIS_H_

#include "XMC4500.h"

#endif // _CMSIS_H_
