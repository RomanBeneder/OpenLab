package openLab.embsysscope.gui.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

public class Controller
{

    @FXML // fx:id="btDrawing"
    private Button btDrawing; // Value injected by FXMLLoader

    @FXML // fx:id="MainBorderPane"
    private BorderPane MainBorderPane; // Value injected by FXMLLoader

}

