package openLab.embsysscope.gui;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class Main extends Application {

	private static final int MAX_DATA_POINTS = 50;
	private int xSeriesData = 0;

	private XYChart.Series<Number, Number> series1 = new XYChart.Series<Number, Number>();
	private XYChart.Series<Number, Number> series2 = new XYChart.Series<Number, Number>();
	private XYChart.Series<Number, Number> series3 = new XYChart.Series<Number, Number>();

	private ExecutorService executor;

	private AddToQueue addToQueue = new AddToQueue();
	private ConcurrentLinkedQueue<Number> dataQ1 = new ConcurrentLinkedQueue<Number>();
	private ConcurrentLinkedQueue<Number> dataQ2 = new ConcurrentLinkedQueue<Number>();
	private ConcurrentLinkedQueue<Number> dataQ3 = new ConcurrentLinkedQueue<Number>();

	private NumberAxis xAxis = new NumberAxis(0,MAX_DATA_POINTS,MAX_DATA_POINTS/10);
	private NumberAxis yAxis = new NumberAxis();


	@Override
	public void start(Stage primaryStage)
	{
		try
		{
			BorderPane root = FXMLLoader.load(Main.class.getResource("TestSample.fxml"));
			javafx.geometry.Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();

			//Setup xAxis
			xAxis.setForceZeroInRange(false);
			xAxis.setAutoRanging(false);
			xAxis.setTickLabelsVisible(false);
			xAxis.setTickMarkVisible(false);
			xAxis.setMinorTickVisible(false);

			//SetupyAxis
			yAxis.setAutoRanging(true);

			//Setup Line Chart
			LineChart<Number, Number> drawingArea = new LineChart<Number, Number>(xAxis, yAxis)
			{
				//Override to remove symbols on each data point
				@Override
				protected void dataItemAdded(Series<Number, Number> series, int itemIndex, Data<Number, Number> item) {}
			};

			drawingArea.setAnimated(false);
			drawingArea.setId("DrawingArea");

			//Setup Chart Series
			drawingArea.getData().addAll(series1, series2, series3);

			root.setLeft(drawingArea);
			Scene scene = new Scene(root,primScreenBounds.getMaxX()/2,primScreenBounds.getMaxY()/2);
			scene.getStylesheets().addAll(this.getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Drawing Example");
			primaryStage.setScene(scene);
			primaryStage.show();

			executor = Executors.newCachedThreadPool(new ThreadFactory()
			{
				@Override
				public Thread newThread(Runnable r)
				{
					Thread thread = new Thread(r);
					thread.setDaemon(false);
					return thread;
				}
			});

			executor.execute(addToQueue);

			startDrawing();

			primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>()
			{
				@Override
				public void handle(WindowEvent event)
				{
					System.exit(0);
				}
			});

		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	private class AddToQueue implements Runnable
	{
		public void run()
		{
			try
			{
				//Random values are add to the queue
				dataQ1.add(Math.random());
				dataQ2.add(Math.random());
				dataQ3.add(Math.random());

				Thread.sleep(500);
				executor.execute(this);
			}

			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}


	private void startDrawing()
	{
		new AnimationTimer()
		{
			@Override
			public void handle(long now)
			{
				addDataToDrawingArea();
			}
		}.start();
	}


	private void addDataToDrawingArea()
	{
		for (int i = 0; i < 20; i++)
		{
			if (dataQ1.isEmpty())
				break;

			series1.getData().add(new Data<Number, Number>(xSeriesData++, dataQ1.remove()));
			series2.getData().add(new Data<Number, Number>(xSeriesData++, dataQ2.remove()));
			series3.getData().add(new Data<Number, Number>(xSeriesData++, dataQ3.remove()));
		}

		//Remove points which are not within the drawing area
		if (series1.getData().size() >= MAX_DATA_POINTS)
		{
			//series1.getData().remove(0, (series1.getData().size() - MAX_DATA_POINTS));
			series1.getData().clear();
		}

		if (series2.getData().size() >= MAX_DATA_POINTS)
		{
			//series2.getData().remove(0, 50);//(series2.getData().size() - MAX_DATA_POINTS));
			series2.getData().clear();
		}

		if (series3.getData().size() >= MAX_DATA_POINTS)
		{
			//series3.getData().remove(0, (series3.getData().size()- MAX_DATA_POINTS));
			series3.getData().clear();
		}

		//Drawing Area Update
		xAxis.setLowerBound(xSeriesData-MAX_DATA_POINTS);
		xAxis.setUpperBound(xSeriesData-1);

		if(xSeriesData >= MAX_DATA_POINTS)
			xSeriesData = 0;
	}


	public static void main(String[] args)
	{
		launch(args);
	}
}

/* EOF */
